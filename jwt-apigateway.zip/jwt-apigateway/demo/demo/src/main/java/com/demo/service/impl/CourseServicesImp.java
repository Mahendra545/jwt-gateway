package com.demo.service.impl;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entity.Course;
import com.demo.repository.CourseRepository;
import com.demo.service.CourseServices;

@Service
public class CourseServicesImp implements CourseServices{

	@Autowired
	CourseRepository courseRepository;
	
	@Override
	public Course saveCourse(Course course) {
		System.out.println("==============================from cpurse service");
		return courseRepository.save(course);
		
	}
	@Override
	public Course getCoursesById(Integer courseId) {
		 Optional<Course> couOptional = courseRepository.findById(courseId);
		  if(couOptional.isPresent()) { return couOptional.get(); } return null;
		 
		
	}
	@Override
	public List<Course> getAllCourses() {
		return courseRepository.findAll();
	}

}