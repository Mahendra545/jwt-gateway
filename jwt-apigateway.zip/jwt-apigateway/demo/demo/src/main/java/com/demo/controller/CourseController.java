package com.demo.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entity.Course;
import com.demo.service.CourseServices;

@RestController
public class CourseController {
	private static final Logger logger = LoggerFactory.getLogger(CourseController.class);
	@Autowired
	CourseServices courseServices;

	@Autowired
	Environment environment;

	@GetMapping("/port")
	public String getPort() {
		return "From Course App : " + environment.getProperty("local.server.port");
	}

	@PostMapping("/course")
	public Course saveCourse(@RequestBody Course course) {
		return courseServices.saveCourse(course);

	}

	@GetMapping("/course/{courseId}")
	public Course getCoursesById(@PathVariable Integer courseId) {
		return courseServices.getCoursesById(courseId);
	}

	@GetMapping("/course")
	public List<Course> getAllCourses() {
		return courseServices.getAllCourses();
	}

}
