package com.demo.service.impl;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.demo.entity.Course;
import com.demo.repository.CourseRepository;

@ExtendWith(MockitoExtension.class)
public class CourseServicesImpTest {
	
	@InjectMocks
	CourseServicesImp courseServicesImp;
	
	@Mock
	CourseRepository courseRepository;
	
	@Test
	public void saveCourseTest() {
		Course course = getCourse();
		Mockito.when(courseRepository.save(Mockito.any())).thenReturn(course);
		Assertions.assertEquals(course.getCourseId(),courseServicesImp.saveCourse(course).getCourseId());
	}
	
	
	private Course getCourse() {
		Course course = new Course();
		course.setCourseId(1);
		course.setCourseName("test");
		course.setStudentId(1);
		return course;
	}

}
