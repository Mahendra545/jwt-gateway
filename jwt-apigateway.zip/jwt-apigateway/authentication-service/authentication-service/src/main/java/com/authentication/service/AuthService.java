package com.authentication.service;

import com.authentication.entity.User;

public interface AuthService {

	String saveUser(User user);

	String generateToken(String username);

	void validateToken(String token);

}
